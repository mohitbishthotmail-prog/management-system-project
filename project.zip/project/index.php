<?php 
include("header.php"); 
include("admin/config.php");
$query = mysqli_query($conn, "SELECT add_service.*, add_category.category 
                              FROM add_service 
                              LEFT JOIN add_category ON add_service.category = add_category.id
                              WHERE add_service.status = 'Enable'") 
          or die("Query failed: " . mysqli_error($conn));
?>
<!-- First Container -->
<div class="container-fluid bg-1 text-center">
  <h3 class="margin">Who Am I?</h3>
  <img src="https://www.investopedia.com/thmb/qjvStnA5-Vv9aAHeobKApiS6IS4=/750x0/filters:no_upscale():max_bytes(150000):strip_icc():format(webp)/GettyImages-1783866205-1ba1e27b9b6a4c1d9f4afafc9c335e1f.jpg" 
       class="profile-img" 
       alt="Bird">
  <h3>I'm an adventurer</h3>
</div>

<div class="container-fluid bg-2 text-center section-bg">
  <h3>What Am I?</h3>
  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua...</p>
  <a href="#" class="btn btn-default btn-lg">
    <span class="glyphicon glyphicon-search"></span> Search
  </a>
</div>

<!-- Third Container (Grid) -->
<div class="container-fluid bg-3 text-center">    
	  <h2>Service</h2>
	  <br>
	  <div class="row">
	  <?php while($row=mysqli_fetch_array($query)) {?>
		<div class="col-sm-4">
		  <p><b><?php echo $row['title'];?></b></p>
		  <p><?php echo $row['description'];?></p>
		  <img src="admin/<?php echo $row['image']; ?>" class="img-responsive margin" style="width:100%; height:350px;object-fit:cover"  alt="Image">
		</div>
	  <?php } ?>
	  </div>
	</div>
	<div id="contact" class="contact-section">
  <div class="container">
    <h3 class="text-center">Contact</h3>
    <p class="text-center"><em>We love our fans!</em></p>

    <div class="row">
      <div class="col-md-4">
        <p>Fan? Drop a note.</p>
        <p><span class="glyphicon glyphicon-map-marker"></span>Chicago, US</p>
        <p><span class="glyphicon glyphicon-phone"></span>Phone: +00 1515151515</p>
        <p><span class="glyphicon glyphicon-envelope"></span>Email: mail@mail.com</p>
      </div>
      <div class="col-md-8">
        <form method="POST" action="">
          <div class="row">
            <div class="col-sm-6 form-group">
              <input class="form-control" id="name" name="name" placeholder="Name" type="text" required>
            </div>
            <div class="col-sm-6 form-group">
              <input class="form-control" id="email" name="email" placeholder="Email" type="email" required>
            </div>
          </div>
          <textarea class="form-control" id="comment" name="comment" placeholder="Comment" rows="5"></textarea>
          <br>
          <div class="row">
            <div class="col-md-12 form-group">
              <button class="btn btn-primary pull-right" type="submit">Send</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php include("footer.php"); ?>

<!-- Extra Styling -->
<style>
  .section-bg {
    background: url('https://images.pexels.com/photos/414612/pexels-photo-414612.jpeg?_gl=1*331kic*_ga*MTg1NjgxMDAxOS4xNzU2NDcxMDk5*_ga_8JE65Q40S6*czE3NTY0NzEwOTkkbzEkZzAkdDE3NTY0NzEwOTkkajYwJGwwJGgw') no-repeat center center/cover;
    color: #fff; /* make text visible */
    padding: 80px 20px;
    position: relative;
  }

  /* Add dark overlay for readability */
  .section-bg::before {
    content: "";
    position: absolute;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(0,0,0,0.6);
    z-index: 1;
  }

  .section-bg h3,
  .section-bg p,
  .section-bg a {
    position: relative;
    z-index: 2;
  }

  /* Button style */
  .section-bg .btn {
    border-radius: 50px;
    padding: 12px 30px;
    font-size: 18px;
    transition: all 0.3s ease;
  }
  .section-bg .btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 6px 20px rgba(0,0,0,0.2);
  }
</style>
<style>
  .profile-img {
    width: 300px;
    height: 300px;
    object-fit: cover;     /* ensures image fills circle without distortion */
    border-radius: 50%;    /* makes perfect circle */
    display: inline-block;
  }
</style>