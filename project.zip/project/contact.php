<?php 
include("header.php"); 
$conn=mysqli_connect("localhost","root","","project") or die("chaeck the connection");
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name    = $_POST['name'];
    $email   = $_POST['email'];
    $comment = $_POST['comment'];

    $query = "INSERT INTO contact (name, email, comment) VALUES ('$name', '$email', '$comment')";
    $result = mysqli_query($conn, $query);
}
?>
<div id="contact" class="contact-section">
  <div class="container">
    <h3 class="text-center">Contact</h3>
    <p class="text-center"><em>We love our fans!</em></p>

    <div class="row">
      <div class="col-md-4">
        <p>Fan? Drop a note.</p>
        <p><span class="glyphicon glyphicon-map-marker"></span>Chicago, US</p>
        <p><span class="glyphicon glyphicon-phone"></span>Phone: +00 1515151515</p>
        <p><span class="glyphicon glyphicon-envelope"></span>Email: mail@mail.com</p>
      </div>
      <div class="col-md-8">
        <form method="POST" action="">
          <div class="row">
            <div class="col-sm-6 form-group">
              <input class="form-control" id="name" name="name" placeholder="Name" type="text" required>
            </div>
            <div class="col-sm-6 form-group">
              <input class="form-control" id="email" name="email" placeholder="Email" type="email" required>
            </div>
          </div>
          <textarea class="form-control" id="comment" name="comment" placeholder="Comment" rows="5"></textarea>
          <br>
          <div class="row">
            <div class="col-md-12 form-group">
              <button class="btn btn-primary pull-right" type="submit">Send</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php include("footer.php"); ?>