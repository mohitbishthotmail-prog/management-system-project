<?php
include("config.php");

if (!isset($_GET['id'])) {
    die("❌ Invalid request!");
}

$id = intval($_GET['id']); // sanitize id

// Delete record directly
$stmt = $conn->prepare("DELETE FROM add_service WHERE id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    header("Location: service.php?msg=deleted");
    exit();
} else {
    die("❌ Error deleting record: " . $conn->error);
}
?>
