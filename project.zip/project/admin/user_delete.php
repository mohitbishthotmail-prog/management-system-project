<?php
include("config.php");

if (isset($_GET['id'])) {
    $id = intval($_GET['id']); // prevent SQL injection

    // Prepare delete query (correct table name: users)
    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        $stmt->close();
        header("Location: users.php?msg=deleted");
        exit();
    } else {
        $stmt->close();
        header("Location: users.php?msg=error");
        exit();
    }

} else {
    header("Location: users.php?msg=invalid");
    exit();
}
?>
