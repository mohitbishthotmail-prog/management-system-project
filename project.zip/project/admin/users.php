<?php
session_start();
include("sidebar.php");
include("config.php");
$query = mysqli_query($conn, "SELECT * FROM users") or die("Query failed: " . mysqli_error($conn));
?>
<div class="content ">
    <nav class="navbar navbar-light bg-white rounded shadow-sm mb-4 px-3">
        <span class="navbar-brand"></span>
        <div>
            <span class="me-3">Hello, <?php echo htmlspecialchars($_SESSION['loged']); ?></span>
        </div>
    </nav>
    <div class="container mt-4">
        <div class="card shadow-sm rounded-3">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0">👥 User List</h5>
                <a href="add_user.php" class="btn btn-light btn-sm">➕ Add User</a>
            </div>

            <div class="card-body">
			     <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>#ID</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Password</th>
                            <th>Date</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $sr = 1;
                        if (mysqli_num_rows($query) > 0) {
                            while ($row = mysqli_fetch_assoc($query)) {
                        ?>
                            <tr>
                                <td><?php echo $sr++; ?></td>
                                <td><?php echo $row['username']; ?></td>
                                <td><?php echo $row['email']; ?></td>
                                <td><?php echo $row['password']; ?></td>                       
                                <td><?php echo date("d M Y", strtotime($row['add_date'])); ?></td>
                                <td class="text-center">
                                    <a href="user_update.php?id=<?php echo (int)$row['id']; ?>" class="btn btn-sm btn-outline-primary">✏️ Update</a>
                                    <a href="user_delete.php?id=<?php echo (int)$row['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Are you sure you want to delete this user?');">🗑 Delete</a>
                                </td>
                            </tr>
                        <?php
                            } // end while
                        } else {
                        ?>
                            <tr>
                                <td colspan="6" class="text-center text-muted fw-bold py-3">
                                    No users found
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
				</div>
            </div>
        </div>
    </div>
</div>
