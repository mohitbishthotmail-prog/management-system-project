<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Dashboard</title>
  <!-- Bootstrap 5 CDN -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      min-height: 100vh;
      display: flex;
    }
       /* Sidebar */
    .sidebar {
      min-width: 220px;
      max-width: 220px;
      background: linear-gradient(135deg, #6f42c1, #20c997);
      color: #fff;
      padding: 20px 0;
    }
    .sidebar h3 {
      font-weight: bold;
    }
    .sidebar a {
      color: #fff;
      text-decoration: none;
      display: block;
      padding: 12px 20px;
      transition: 0.3s;
      font-weight: 500;
    }
    .sidebar a:hover {
      background: rgba(255,255,255,0.15);
      border-radius: 10px;
      padding-left: 25px;
    }
	/* Navbar */
    .navbar {
      background: #fff;
      box-shadow: 0 4px 6px rgba(0,0,0,0.05);
      padding: 15px 20px;
    }
    .content {
      flex: 1;
      padding: 0;
    }
    .card {
      border-radius: 15px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.1);
      transition: transform 0.2s;
    }
    .card:hover {
      transform: translateY(-5px);
    }
    .card h2 {
      font-size: 2rem;
      margin: 0;
    }
	.icon-circle {
      width: 50px;
      height: 50px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      color: #fff;
    }
    .bg-purple { background: #6f42c1; }
    .bg-teal { background: #20c997; }
    .bg-orange { background: #fd7e14; }
  </style>
</head>
<body>

  <!-- Sidebar -->
 <div class="sidebar d-flex flex-column">
    <h3 class="text-center mb-4">MyApp</h3>
    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="category.php">📊 Category</a>
    <a href="users.php">👤 Users</a>
    <a href="service.php">⚙️ Service</a>
    <a href="enquery.php">📩 Enquiry</a>
    <a href="logout.php">🚪 Logout</a>
 </div>

