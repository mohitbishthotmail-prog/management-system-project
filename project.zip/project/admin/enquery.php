<?php 
include("sidebar.php");

$conn = mysqli_connect("localhost","root","","project") or die("Check the connection");
if (isset($_GET['delete_id'])) {
    $id = (int)$_GET['delete_id'];
    mysqli_query($conn, "DELETE FROM contact WHERE id=$id") or die("Delete failed: " . mysqli_error($conn));
    header("Location: enquery.php"); // refresh after delete
    exit;
}
$query  = "SELECT * FROM contact ORDER BY id DESC";
$result = mysqli_query($conn, $query) or die("Query failed: " . mysqli_error($conn));
?>
  <div class="container mt-4">
    <div class="col-md-12">
      <div class="card shadow-sm rounded-3">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
          <h5 class="mb-0"> 📩 Enquiry</h5>  
        </div>

        <div class="card-body">
          <table class="table table-hover align-middle">
            <thead class="table-dark">
              <tr>
                <th>#ID</th>
                <th>Username</th>
                <th>Email</th>
                <th>Comment</th>
                <th class="text-center">Action</th>
              </tr>
            </thead>
            <tbody>
              <?php
              $sr = 1;
              if (mysqli_num_rows($result) > 0) {
                  while ($row = mysqli_fetch_assoc($result)) { ?>
                      <tr>
                        <td><?php echo $sr++; ?></td>
                        <td><?php echo $row['name']; ?></td>
                        <td><?php echo $row['email']; ?></td>
                        <td><?php echo $row['comment']; ?></td>				   
						 <td class="text-center">
							<a href="enquery.php?delete_id=<?php echo $row['id']; ?>" 
                               class="btn btn-sm btn-outline-danger" 
                               onclick="return confirm('Are you sure you want to delete this enquiry?');">
                               🗑 Delete
                            </a>
						 </td>
                         </td>
                      </tr>
                  <?php }
              } else { ?>
                  <tr>
                    <td colspan="5" class="text-center">No enquiries found.</td>
                  </tr>
              <?php } ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
