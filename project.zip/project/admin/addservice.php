<?php
session_start();
include("sidebar.php");
include("config.php");

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $title       = trim($_POST['title']);
    $description = $_POST['description'];
	$category_id = $_POST['category'];
    $status      = $_POST['status'];
    $date        = date("Y-m-d");
    $imagePath   = "";

    
    if (!empty($_FILES['image']['name'])) {
        $imagePath = "uploads/" . basename($_FILES['image']['name']);
        move_uploaded_file($_FILES['image']['tmp_name'], $imagePath);
    }

    $check = $conn->prepare("SELECT id FROM add_service WHERE title = ?");
    $check->bind_param("s", $title);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        echo "<script>alert('⚠️ Service with this title already exists!'); window.location='addservice.php';</script>";
    } else {
        // ✅ Insert new service with category
        $stmt = $conn->prepare("INSERT INTO add_service (category, title, description, image, status, date) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("isssss", $category_id, $title, $description, $imagePath, $status, $date);
        $stmt->execute();

        echo "<script>alert('✅ Service added successfully!'); window.location='service.php';</script>";
    }
    $check->close();
}

// ✅ Fetch categories
$categories = [];
$result = $conn->query("SELECT id, category AS name FROM add_category ORDER BY category ASC");
while ($row = $result->fetch_assoc()) {
    $categories[] = $row;
}
?>
<div class="container mt-4">
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="card s6hadow-sm rounded-3">
        <div class="card-header bg-primary text-white">
          <h5 class="mb-0">➕ Add Service</h5>
        </div>
        <div class="card-body">
          <form action="" method="POST" enctype="multipart/form-data">  
		  
		    <div class="mb-3">
			  <label for="category" class="form-label">Category</label>
			  <select name="category" id="category" class="form-select" required>
				<option value="">-- Select Category --</option>
				<?php foreach ($categories as $cat): ?>
				  <option value="<?= $cat['id']; ?>"><?= htmlspecialchars($cat['name']); ?></option>
				<?php endforeach; ?>
			  </select>
			</div>
 
            <div class="mb-3">
              <label for="title" class="form-label">Title</label>
              <input type="text" id="title" name="title" class="form-control" placeholder="Enter service title" required>
            </div>

            
            <div class="mb-3">
              <label for="description" class="form-label">Description</label>
              <textarea id="description" name="description" class="form-control" rows="3" placeholder="Enter service description" required></textarea>
            </div>

          
            <div class="mb-3">
              <label for="image" class="form-label">Upload Image</label>
              <input type="file" id="image" name="image" class="form-control" accept="image/*">
            </div>

          
            <div class="mb-3">
              <label class="form-label">Status</label>
              <select name="status" class="form-select" required>
                <option value="Enable">Enable</option>
                <option value="Disable">Disable</option>
              </select>
            </div>
            
           
            <div class="d-grid">
              <button type="submit" class="btn btn-primary">💾 Submit</button>
            </div>

          </form>
        </div>
      </div>
    </div>
  </div>
</div>
