<?php
include("sidebar.php");
include("config.php");

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $username = trim($_POST['username']);
    $email    = trim($_POST['email']);
    $password = md5($_POST['password']);  // ⚠️ better to use password_hash() for security
    $date     = date("Y-m-d H:i:s");

    // ✅ Check if user already exists (by email or username)
    $check = $conn->prepare("SELECT id FROM users WHERE email = ? OR username = ?");
    $check->bind_param("ss", $email, $username);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        // ❌ User already exists
        echo "<script>alert('⚠️ User with this email or username already exists!'); window.location='users.php';</script>";
    } else {
        // ✅ Insert new user
        $stmt = $conn->prepare("INSERT INTO users (username, email, password, add_date) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $username, $email, $password, $date);
        $stmt->execute();

        echo "<script>alert('✅ User added successfully!'); window.location='users.php';</script>";
    }
    $check->close();
}
?>

<div class="container mt-4">
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="card shadow-sm rounded-3">
        <div class="card-header bg-primary text-white">
          <h5 class="mb-0">➕ Add User</h5>
        </div>
        <div class="card-body">
          <form action="" method="POST">
            
            <div class="mb-3">
              <label for="username" class="form-label">Username</label>
              <input type="text" id="username" name="username" class="form-control" required>
            </div>

            <div class="mb-3">
              <label for="email" class="form-label">Email</label>
              <input type="email" id="email" name="email" class="form-control" required>
            </div>

            <div class="mb-3">
              <label for="password" class="form-label">Password</label>
              <input type="password" id="password" name="password" class="form-control" required>
            </div>

            <div class="d-grid">
              <button type="submit" class="btn btn-primary">💾 Save User</button>
            </div>

          </form>
        </div>
      </div>
    </div>
  </div>