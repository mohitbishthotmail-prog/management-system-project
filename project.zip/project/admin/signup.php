<?php
session_start();
include("sidebar.php");
?>  <!-- Main Content -->
  <div class="content">
    <!-- Top Navbar -->
    <nav class="navbar navbar-light bg-white rounded shadow-sm mb-4 px-3">
      <span class="navbar-brand">Dashboard</span>
      <div>
        <span class="me-3">Hello, <?php echo $_SESSION['loged'];?></span>
      </div>
    </nav>
<?php 

include("config.php");
  if ($_SERVER['REQUEST_METHOD'] == "POST") 
  {
      $username = $_POST['username'];
      $email = $_POST['email'];
      $password = $_POST['password']; 
	  $stmt=$conn->prepare("insert into users (username,email,password) value(?,?,?)");
	  $stmt->bind_param("sss", $username, $email, $password);
	  $stmt->execute();	
	  $msg=1;
  }
?>

</head>
<style>
  .btn-custom {
  background: #0d6efd; /* Bootstrap Primary Blue */
  color: #fff;
  border-radius: 12px;
  transition: 0.3s;
}
.btn-custom:hover {
  background: #0b5ed7; /* Darker Blue on hover */
}
</style>
<body>

  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-6 col-lg-5">
        <div class="card p-4">
          <h2 class="text-center mb-4">Create Account</h2>
          <form method="post">
            <div class="mb-3">
              <label class="form-label">Username</label>
              <input type="text" class="form-control" name="username" placeholder="Enter your name">
            </div>
            <div class="mb-3">
              <label class="form-label">Email</label>
              <input type="email" class="form-control" name="email" placeholder="Enter your email">
            </div>
            <div class="mb-3">
              <label class="form-label">Password</label>
              <input type="password" class="form-control" name="password" placeholder="Enter password">
            </div>
            
            <button type="submit" class="btn btn-custom w-100">Sign Up</button>
          </form>
          
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>


  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
