<?php
session_start();
include("config.php");
if(isset($_SESSION['loged'])) :
	header("location:dashboard.php");
endif; 
 if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  //   $username = $_POST['username'];
   //  $password = md5($_POST['password']);
	
	$username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, md5($_POST['password']));
	

	$sql="select * from users where username='$username' AND password='$password'";
	 $query=mysqli_query($conn,$sql) or die("Check the query");
	 $count=mysqli_num_rows($query);
	 if($count>=1)
	 {
		 $_SESSION['loged']=$username;
		 header("location:dashboard.php");
	 }
	 else{
		 $error=1;
	 }
	 
}

 ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login Page</title>
  <!-- Bootstrap 5 CDN -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      min-height: 100vh;
      background: linear-gradient(135deg, #20c997, #6f42c1);
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .card {
      border-radius: 20px;
      box-shadow: 0 8px 25px rgba(0,0,0,0.2);
    }
    .form-control {
      border-radius: 12px;
    }
    .btn-custom {
      background: #20c997;
      color: #fff;
      border-radius: 12px;
      transition: 0.3s;
    }
    .btn-custom:hover {
      background: #198754;
    }
  </style>
</head>
<body>

  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-6 col-lg-5">
        <div class="card p-4">
          <h2 class="text-center mb-4">Log in </h2>
		  <?php if (!empty($error)) : ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
              Wrong username or password. Please try again.
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
          <?php endif; ?>
          <form method="post">
            <div class="mb-3">
              <label class="form-label">Username</label>
              <input type="text" class="form-control" placeholder="Enter your email" name="username" >
            </div>
            <div class="mb-3">
              <label class="form-label">Password</label>
              <input type="password" class="form-control" placeholder="Enter password" name="password" >
            </div>
            <div class="d-flex justify-content-between mb-3">
              <div>
                <input type="checkbox" id="remember">
                <label for="remember">Remember me</label>
              </div>
              <a href="#" class="text-decoration-none">Forgot password?</a>
            </div>
            <button type="submit" class="btn btn-custom w-100">Login</button>
          </form>
          <p class="text-center mt-3">
            Don’t have an account? <a href="signup.php">Sign Up</a>
          </p>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
