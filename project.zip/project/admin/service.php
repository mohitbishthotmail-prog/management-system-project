<?php
session_start();
include("sidebar.php");
include("config.php");

if (isset($_GET['toggle_id']) && isset($_GET['status'])) {
    $id = $_GET['toggle_id'];
    $status = $_GET['status'];
    $newStatus = ($status == 'Enable') ? 'Disable' : 'Enable';
    mysqli_query($conn, "UPDATE add_service SET status='$newStatus' WHERE id='$id'");
    header("Location: service.php");
    exit;
}

$query = mysqli_query($conn, "SELECT add_service.*,add_category.category FROM add_service LEFT JOIN add_category
On add_service.category=add_category.id
") 
          or die("Query failed: " . mysqli_error($conn));
?>
<div class="content">
  <nav class="navbar navbar-light bg-white rounded shadow-sm mb-4 px-3">
    <span class="navbar-brand"></span>
    <div>
      <span class="me-3">Hello, <?php echo htmlspecialchars($_SESSION['loged']); ?></span>
    </div>
  </nav>

  <div class="container mt-4">
    <div class="card shadow-sm rounded-3">
      <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
        <h5 class="mb-0">🛠 Service List</h5>
        <a href="addservice.php" class="btn btn-light btn-sm">➕ Add Service</a>
      </div>

      <div class="card-body">
        <!-- Make table responsive -->
        <div class="table-responsive">
          <table class="table table-hover align-middle">
            <thead class="table-dark">
              <tr>
                <th scope="col">#ID</th>
                <th scope="col">Title</th>
                <th scope="col">Description</th>
                <th scope="col">Category</th>
                <th scope="col">Image</th>
                <th scope="col">Status</th>
                <th scope="col">Date</th>
                <th scope="col" class="text-center">Action</th>
              </tr>
            </thead>
            <tbody>
            <?php
              $sr = 1;
              if ($query && $query->num_rows > 0) {
                  while ($row = $query->fetch_assoc()) {

                      // fetch category name separately
                     $catName = !empty($row['category']) ? $row['category'] : 'Unknown';

            ?>
              <tr>
                <td><?php echo $sr++; ?></td>
                <td><?php echo htmlspecialchars($row['title']); ?></td>
                <td><?php echo htmlspecialchars($row['description']); ?></td>
                <td><?php echo htmlspecialchars($catName); ?></td>
                <td>
                    <?php if (!empty($row['image'])): ?>
                        <img src="<?php echo htmlspecialchars($row['image']); ?>" height="50" width="50" alt="Service Image">
                    <?php else: ?>
                        <span class="text-muted">No Image</span>
                    <?php endif; ?>
                </td>
                <td>
                  <a href="service.php?toggle_id=<?php echo $row['id']; ?>&status=<?php echo urlencode($row['status']); ?>" 
                     class="badge <?php echo ($row['status'] === 'Enable') ? 'bg-success' : 'bg-danger'; ?>" 
                     style="text-decoration:none;">
                     <?php echo $row['status']; ?>
                  </a>
                </td>
                <td><?php echo date("d M Y", strtotime($row['date'])); ?></td>
                <td class="text-center">
                  <a href="service_update.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-outline-primary">✏️ Update</a>
                  <form action="service_delete.php" method="POST" style="display:inline;">
                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                    <button type="submit" 
                            class="btn btn-sm btn-outline-danger"
                            onclick="return confirm('Are you sure you want to delete this service?');">
                      🗑 Delete
                    </button>
                  </form>
                </td>
              </tr>
            <?php 
                  } // end while
              } else { 
            ?>
              <tr>
                <td colspan="8" class="text-center text-muted fw-bold py-3">
                   No services found
                </td>
              </tr>
            <?php } ?>
            </tbody>
          </table>
        </div> 
      </div> 
    </div> 
  </div> 
</div> 

