<?php
include("config.php");

// ✅ Check if `id` is passed
if (isset($_GET['id'])) {
    $id = intval($_GET['id']); // prevent SQL injection

    // Prepare delete query
    $stmt = $conn->prepare("DELETE FROM add_user WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo "<script>alert('✅ Record deleted successfully!'); window.location='category.php';</script>";
    } else {
        echo "<script>alert('❌ Failed to delete record!'); window.location='category.php';</script>";
    }

    $stmt->close();
} else {
    echo "<script>alert('⚠️ Invalid request!'); window.location='category.php';</script>";
}
?>
