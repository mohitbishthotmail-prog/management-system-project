<?php
session_start();
include("sidebar.php");
include("config.php");

// Get service ID
$id = $_GET['id'];

// Fetch existing service data
$result = mysqli_query($conn, "SELECT * FROM add_service WHERE id='$id'");
$service = mysqli_fetch_assoc($result);

// Fetch categories for dropdown (use add_category table if that's the correct one)
$categories = [];
$catResult = mysqli_query($conn, "SELECT * FROM add_category"); 
while ($row = mysqli_fetch_assoc($catResult)) {
    $categories[] = $row;
}

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $category_id = $_POST['category'];  // ✅ Get selected category id
    $title = $_POST['title'];
    $description = $_POST['description'];
    $status = $_POST['status'];
    $date = date("Y-m-d");

    // Keep old image by default
    $imagePath = $service['image'];
    if (!empty($_FILES['image']['name'])) {
        $imagePath = "uploads/" . basename($_FILES['image']['name']);
        move_uploaded_file($_FILES['image']['tmp_name'], $imagePath);
    }

    // ✅ Update record with category_id
    $stmt = $conn->prepare("UPDATE add_service 
                            SET category=?, title=?, description=?, image=?, status=?, date=? 
                            WHERE id=?");
    $stmt->bind_param("isssssi", $category_id, $title, $description, $imagePath, $status, $date, $id);
    $stmt->execute();

    header("Location: service.php");
    exit;
}
?>



<div class="container mt-4">
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="card shadow-sm rounded-3">
        <div class="card-header bg-primary text-white">
          <h5 class="mb-0">✏️ Update Service</h5>
        </div>
        <div class="card-body">
          <form action="" method="POST" enctype="multipart/form-data">  
            
			<div class="mb-3">
			  <label for="category" class="form-label">Category</label>
			  <select name="category" id="category" class="form-select" required>
				<option value="">-- Select Category --</option>
				<?php foreach ($categories as $cat) { ?>
				  <option value="<?= $cat['id'] ?>" <?= ($cat['id'] == $service['category']) ? 'selected' : '' ?>>
					<?= htmlspecialchars($cat['category']) ?>
				  </option>
				<?php } ?>
			  </select>
			</div>


            <div class="mb-3">
              <label for="title" class="form-label">Title</label>
              <input type="text" id="title" name="title" class="form-control" value="<?php echo $service['title']; ?>" required>
            </div>

            <div class="mb-3">
              <label for="description" class="form-label">Description</label>
              <textarea id="description" name="description" class="form-control" rows="3" required><?php echo $service['description']; ?></textarea>
            </div>

            <div class="mb-3">
              <label for="image" class="form-label">Upload Image</label>
              <input type="file" id="image" name="image" class="form-control" accept="image/*">
              <?php if($service['image']) { ?>
                <div class="mt-2">
                  <img src="<?php echo $service['image']; ?>" height="100">
                </div>
              <?php } ?>
            </div>

            <div class="mb-3">
              <label class="form-label">Status</label>
              <select name="status" class="form-select" required>
                <option value="Enable" <?php if($service['status']=="Enable") echo "selected"; ?>>Enable</option>
                <option value="Disable" <?php if($service['status']=="Disable") echo "selected"; ?>>Disable</option>
              </select>
            </div>
            
            <div class="d-grid">
              <button type="submit" class="btn btn-primary">💾 Update</button>
            </div>

          </form>
        </div>
      </div>
    </div>
  </div>
</div>
