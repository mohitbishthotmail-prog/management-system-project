<?php
session_start();
include("sidebar.php");
?>  <!-- Main Content -->
  <div class="content">
    <!-- Top Navbar -->
    <nav class="navbar navbar-light bg-white rounded shadow-sm mb-4 px-3">
      <span class="navbar-brand">Dashboard</span>
      <div>
        <span class="me-3">Hello, <?php echo $_SESSION['loged'];?></span>
      </div>
    </nav>

     <div class="container-fluid p-4">
      <div class="row g-4">
        <!-- Card 1 -->
        <div class="col-md-4">
          <div class="card p-3 d-flex flex-row align-items-center">
            <div class="icon-circle bg-purple me-3">👤</div>
            <div>
              <h5>Total Users</h5>
              <h2>1,245</h2>
            </div>
          </div>
        </div>

        <!-- Card 2 -->
        <div class="col-md-4">
          <div class="card p-3 d-flex flex-row align-items-center">
            <div class="icon-circle bg-teal me-3">⚙️</div>
            <div>
              <h5>Active Services</h5>
              <h2>52</h2>
            </div>
          </div>
        </div>

        <!-- Card 3 -->
        <div class="col-md-4">
          <div class="card p-3 d-flex flex-row align-items-center">
            <div class="icon-circle bg-orange me-3">📩</div>
            <div>
              <h5>Pending Enquiries</h5>
              <h2>18</h2>
            </div>
          </div>
        </div>
      </div>

      <!-- Table -->
      <div class="card mt-4">
        <div class="card-body">
          <h5 class="card-title mb-3">Recent Enquiries</h5>
          <table class="table align-middle table-hover">
            <thead class="table-light">
              <tr>
                <th>#</th>
                <th>Name</th>
                <th>Email</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>1</td>
                <td>Alice</td>
                <td>alice@example.com</td>
                <td><span class="badge bg-warning">Pending</span></td>
              </tr>
              <tr>
                <td>2</td>
                <td>Bob</td>
                <td>bob@example.com</td>
                <td><span class="badge bg-success">Resolved</span></td>
              </tr>
              <tr>
                <td>3</td>
                <td>Charlie</td>
                <td>charlie@example.com</td>
                <td><span class="badge bg-danger">Open</span></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>