<?php
include("sidebar.php");
include("config.php");

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $id = $_POST['id'];
    $category = $_POST['category'];
    $status   = $_POST['status'];
    $stmt = $conn->prepare("UPDATE add_category SET category=?, status=? WHERE id=?");
    $stmt->bind_param("ssi", $category, $status, $id);
    $stmt->execute();

    header("Location: category.php");
    exit();
}
$id = $_GET['id'];
$result = mysqli_query($conn, "SELECT * FROM add_category WHERE id=$id");
$row = mysqli_fetch_assoc($result);
?>

<div class="container mt-4">
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">✏️ Update Category</div>
        <div class="card-body">
          <form method="POST">
            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">

            <div class="mb-3">
              <label class="form-label">Category</label>
              <input type="text" name="category" class="form-control" value="<?php echo $row['category']; ?>" required>
            </div>

            <div class="mb-3">
              <label class="form-label">Status</label>
              <select name="status" class="form-select">
                <option value="Enable"  <?php if($row['status']=="Enable")  echo "selected"; ?>>Enable</option>
                <option value="Disable" <?php if($row['status']=="Disable") echo "selected"; ?>>Disable</option>
              </select>
            </div>

            <button type="submit" class="btn btn-primary w-100">💾 Update</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
