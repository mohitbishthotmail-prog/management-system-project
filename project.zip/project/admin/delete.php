<?php
include("config.php");

if (isset($_GET['id'])) {
    $id = intval($_GET['id']); // get id from URL safely

    $stmt = $conn->prepare("DELETE FROM add_category WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        // redirect with success flag
        header("Location: category.php?msg=deleted");
        exit();
    } else {
        echo "Error deleting record: " . $conn->error;
    }
} else {
    echo "Invalid request!";
}
?>
