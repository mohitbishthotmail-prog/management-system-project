<?php
session_start();
include("sidebar.php");
include("config.php");
date_default_timezone_set("Asia/Kolkata"); // preferred name

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $category = trim($_POST['category']);
    $status   = $_POST['status'];
    $date     = date("Y-m-d H:i:s");
	
    $check = $conn->prepare("SELECT id FROM add_category WHERE category = ?");
    $check->bind_param("s", $category);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        
        echo "<script>alert('⚠️ Record already exists!'); window.location='addcategory.php';</script>";
    } else {
        
        $stmt = $conn->prepare("INSERT INTO add_category(category, status, added_date) VALUES(?,?,?)");
        $stmt->bind_param("sss", $category, $status, $date);
        $stmt->execute();

        echo "<script>alert('✅ Category added successfully!'); window.location='category.php';</script>";
    }

    $check->close();
}
?>


<div class="container mt-4">
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="card shadow-sm rounded-3">
        <div class="card-header bg-primary text-white">
          <h5 class="mb-0">➕ Add Category</h5>
        </div>
        <div class="card-body">
          <form action="" method="POST">
           
            <div class="mb-3">
              <label for="category" class="form-label">Category </label>
              <input type="text" id="category" name="category" class="form-control" placeholder="Enter category name" required>
            </div>
            
            <div class="mb-3">
              <label class="form-label">Status</label>
              <select name="status" class="form-select" required>
                <option>Enable</option>
                <option>Disable</option>
              </select>
            </div>
          
            <div class="d-grid">
              <button type="submit" class="btn btn-primary">💾 Submit</button>
            </div>

          </form>
        </div>
      </div>
    </div>
  </div>
</div>

