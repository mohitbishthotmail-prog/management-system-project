<?php
include("sidebar.php");
include("config.php");

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: users.php");
    exit();
}

$id = intval($_GET['id']);

// ✅ Fetch existing user
$result = $conn->query("SELECT * FROM users WHERE id=$id");
if ($result->num_rows == 0) {
    echo "<script>alert('User not found!'); window.location='users.php';</script>";
    exit();
}
$user = $result->fetch_assoc();

// ✅ Update
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $username = trim($_POST['username']);
    $email    = trim($_POST['email']);
    $password = !empty($_POST['password']) ? md5($_POST['password']) : $user['password'];
    $date     = date("Y-m-d H:i:s");

    $conn->query("UPDATE add_user SET username='$username', email='$email', password='$password', date='$date' WHERE id=$id");

    echo "<script>alert('User updated successfully!'); window.location='users.php';</script>";
}
?>

<div class="container mt-4">
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="card shadow-sm rounded-3">
        <div class="card-header bg-primary text-white">
          <h5 class="mb-0">✏️ Update User</h5>
        </div>
        <div class="card-body">
          <form action="" method="POST">
            
            <div class="mb-3">
              <label class="form-label">Username</label>
              <input type="text" name="username" class="form-control" value="<?php echo $user['username']; ?>" required>
            </div>

            <div class="mb-3">
              <label class="form-label">Email</label>
              <input type="email" name="email" class="form-control" value="<?php echo $user['email']; ?>" required>
            </div>

            <div class="mb-3">
              <label class="form-label">Password</label>
              <input type="password" name="password" class="form-control" placeholder="Leave blank to keep old password">
            </div>

            <div class="d-grid">
              <button type="submit" class="btn btn-primary">💾 Update</button>
            </div>

          </form>
        </div>
      </div>
    </div>
  </div>
</div>
