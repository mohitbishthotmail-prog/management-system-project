<!DOCTYPE html>
<html lang="en">
<head>
  <title>My Website</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat|Lato" rel="stylesheet">

  <!-- jQuery & Bootstrap JS -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

  <style>
    body {
      font: 20px Montserrat, sans-serif;
      line-height: 1.8;
      color: #f5f6f7;
    }
    p { font-size: 16px; }
    .margin { margin-bottom: 45px; }

    .bg-1 { background-color: #1abc9c; color: #ffffff; }
    .bg-2 { background-color: #474e5d; color: #ffffff; }
    .bg-3 { background-color: #ffffff; color: #555555; }
    .bg-4 { background-color: #2f2f2f; color: #fff; }

    .container-fluid {
      padding-top: 70px;
      padding-bottom: 70px;
    }

    .navbar {
      padding-top: 15px;
      padding-bottom: 15px;
      border: 0;
      border-radius: 0;
      margin-bottom: 0;
      font-size: 12px;
      letter-spacing: 5px;
    }
    .navbar-nav li a:hover {
      color: #1abc9c !important;
    }
/* Contact section with background image */
.contact-section {
  position: relative;
  background: url('https://image-processor-storage.s3.us-west-2.amazonaws.com/images/3cf61c1011912a2173ea4dfa260f1108/halo-of-neon-ring-illuminated-in-the-stunning-landscape-of-yosemite.jpg') no-repeat center center fixed; 
  background-size: cover;
  padding: 80px 20px;
  font-family: 'Montserrat', sans-serif;  /* Use Montserrat */
  font-size: 20px;                        /* Set base size */
  color: #fff;
  letter-spacing: 5px;
}

/* Dark overlay for readability */
.contact-section::before {
  content: "";
  position: absolute;
  top: 0; left: 0; right: 0; bottom: 0;
  background: rgba(0,0,0,0.6);
  z-index: 1;
}

.contact-section .container {
  position: relative;
  z-index: 2; /* keep content above overlay */
}

/* Headings */
.contact-section h3 {
  font-size: 32px;   /* Bigger than base */
  font-weight: 700;
  color: #fff;
  text-transform: uppercase;
}

.contact-section p {
  font-size: 20px;
  color: #ddd;
}

/* Contact Info */
.contact-info p {
  margin: 10px 0;
}

/* Form card effect */
.contact-section form {
  background: rgba(255,255,255,0.95);
  border-radius: 12px;
  padding: 30px;
  box-shadow: 0 6px 20px rgba(0,0,0,0.3);
  color: #222;
}

.contact-section .form-control {
  border-radius: 8px;
  font-size: 20px; /* match font size */
  font-family: 'Montserrat', sans-serif;
  padding: 14px;
}

.contact-section button {
  border-radius: 8px;
  padding: 12px 30px;
  font-size: 20px; /* match font size */
  font-family: 'Montserrat', sans-serif;
  font-weight: 600;
}
/* Global Font */
body {
  font-family: 'Montserrat', sans-serif;
  font-size: 20px;
}
  </style>
  
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-default">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="index.php">MySite</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="about.php">ABOUT</a></li>
        <li><a href="service.php">SERVICE</a></li>
        <li><a href="contact.php">CONTACT</a></li>
      </ul>
    </div>
  </div>
</nav>
