<?php include("header.php");
include("admin/config.php");
$query = mysqli_query($conn, "SELECT add_service.*, add_category.category 
                              FROM add_service 
                              LEFT JOIN add_category ON add_service.category = add_category.id
                              WHERE add_service.status = 'Enable'") 
          or die("Query failed: " . mysqli_error($conn));


 ?>
	<div class="container-fluid bg-3 text-center">    
	  <h3 class="margin">Service</h3><br>
	  <div class="row">
	  <?php while($row=mysqli_fetch_array($query)) {?>
		<div class="col-sm-4">
		  <p><b><?php echo $row['title'];?></b></p>
		  <p><?php echo $row['description'];?></p>
		  <img src="admin/<?php echo $row['image']; ?>" class="img-responsive margin" style="width:100%; height:350px;object-fit:cover"  alt="Image">
		</div>
	  <?php } ?>
	  </div>
	</div>
<?php include("footer.php"); ?>	